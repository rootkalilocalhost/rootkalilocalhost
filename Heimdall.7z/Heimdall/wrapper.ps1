function Start-Sleep($seconds) {
    $doneDT = (Get-Date).AddSeconds($seconds)
    while ($doneDT -gt (Get-Date)) {
        $secondsLeft = $doneDT.Subtract((Get-Date)).TotalSeconds
        $percent = ($seconds - $secondsLeft) / $seconds * 100
        Write-Progress -Activity "Sleeping" -Status "Sleeping..." -SecondsRemaining $secondsLeft -PercentComplete $percent
        [System.Threading.Thread]::Sleep(500)
    }
    Write-Progress -Activity "Sleeping" -Status "Sleeping..." -SecondsRemaining 0 -Completed
}
while ($true) {
    Start-Process -FilePath "pwsh" -ArgumentList "$PSScriptRoot\Main.ps1" -NoNewWindow -Wait
    $WaitTime = 700 + (Get-Random -Minimum 100 -Maximum 200)
    Start-Sleep $WaitTime
}