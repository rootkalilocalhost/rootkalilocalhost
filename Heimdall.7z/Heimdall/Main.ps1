﻿using module ..\Classes\classes.psm1

$ErrorActionPreference = "Continue";
[Console]::OutputEncoding = [Text.UTF8Encoding]::UTF8;
$ConfigPath = Join-Path -Path $PSScriptRoot -ChildPath "tg-bot.xml";
[xml]$xmlConfig = Get-Content -Path $ConfigPath;
$token = $xmlConfig.config.system.token;
$GroupID = $xmlConfig.config.system.group_id;
# Telegram URLs
$URL_SendMessage = "https://api.telegram.org/bot$token/sendMessage";

$LastHash = $xmlConfig.config.lasthash;

<# Links:
AS Numbers - AS Names:
https://ftp.ripe.net/ripe/asnames/asn.txt

IPv4 - AS Number
https://thyme.apnic.net/current/data-raw-table

IPv6 - AS Number
https://thyme.apnic.net/current/ipv6-raw-table

Public DNS Servers:
https://public-dns.info/nameservers.txt

IT Army target list:
https://raw.githubusercontent.com/db1000n-coordinators/LoadTestConfig/main/config.v0.7.json
https://api.github.com/repos/db1000n-coordinators/LoadTestConfig/commits
#>
function Get-File() {
    param (
        [Parameter(Mandatory = $True)]
        [string]
        $URL,
        [Parameter(Mandatory = $True)]
        [string]
        $FileName
    )
    $httpClient = New-Object System.Net.Http.HttpClient;
    $null = $httpClient.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
    $Response = $httpClient.GetAsync($URL);
    try {
        $Response.Wait();
    }
    catch {
        return $false;
    }
    $FileStream = New-Object System.IO.FileStream($FileName, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write);
    $DownloadTask = $Response.Result.Content.CopyToAsync($FileStream);
    $null = $DownloadTask.Wait();
    $null = $FileStream.Close();
    $null = $httpClient.Dispose();
    return $true;
}

function CreateTargetList() {
    $ITArmyTargets = @();
    $ITArmyTargetsCleaned = @();
    # Adding targets from IT ARMY
    $TempFilePath = Join-Path -Path $PSScriptRoot -ChildPath "temp";
    Get-File "https://raw.githubusercontent.com/db1000n-coordinators/LoadTestConfig/main/config.v0.7.json" $TempFilePath;
    $JsonData = Get-Content -Path $TempFilePath | ConvertFrom-Json;
    Remove-Item -Force -Path $TempFilePath | Out-Null;
    $Jobs = $JsonData.jobs;
    $Paths = @("args.request.path",
        "args.client.static_host.addr",
        "args.connection.args.address")
    foreach ($Job in $Jobs) {
        foreach ($Path in $Paths) {
            $SafePath = $Path -replace '(`)*\$', '$1$1`$$';
            # Generally iex should be avoided. THIS is a rare exception.
            $Val = Invoke-Expression "`$Job.$SafePath"
            if ($null -eq $Val) {
                Out-Null;
            }
            else {
                $ITArmyTargets += "$Val";
            }
        }
    }
    # Cleanup
    $ITArmyTargets = $ITArmyTargets -join " ";
    $ITArmyTargets = $ITArmyTargets -replace '`n', ' ';
    $ITArmyTargets = $ITArmyTargets -replace '`r', ' ';
    $ITArmyTargets = $ITArmyTargets -replace '`t', ' ';
    $ITArmyTargets = $ITArmyTargets -replace ',', ' ';
    $ITArmyTargets = $ITArmyTargets -replace '  ', ' ';
    $ITArmyTargets = $ITArmyTargets.Replace("tcp)", "tcp");
    $ITArmyTargets = $ITArmyTargets -split " ";
    foreach ($target in $ITArmyTargets) {
        $Cl_target = $target.Split("://")[-1];
        $Cl_target = $Cl_target.Split(":")[0];
        $ITArmyTargetsCleaned += $Cl_target
    }
    $TargetsCleaned = $ITArmyTargetsCleaned | Select-Object -Unique | Sort-Object;
    return $TargetsCleaned
}

function IsIP {
    param (
        [string] $Value = $null
    )
    if ($null -eq $Value) {
        return $false;
    }
    try {
        $null = [ipaddress] $Value
    }
    catch {
        return $false
    }
    return $true;
}

function Announce {
    param (
        [string] $Text = $null
    )
    if ($null -eq $Text) {
        return $false;
    }
    $null = [System.Console]::Write($Text);

}
#############################################################################################################
################ Telegram functions #########################################################################
function SendMessage($ChatID, $text, $ReplyTo = $null) {
    if ((-not $ChatID) -or (-not $text)) {
        Write-Error "[E] Function SendMessage called without critical parameter! $ChatID $text"
        return $null
    }
    if ($null -eq $ReplyTo) {
        $ht = @{
            text       = $text
            parse_mode = "HTML"
            chat_id    = $ChatID
        }

    }
    else {
        $ht = @{
            text                = $text
            parse_mode          = "HTML"
            chat_id             = $ChatID
            reply_to_message_id = $ReplyTo
        }
    }

    $json = $ht | ConvertTo-Json
    $Temp = Invoke-RestMethod $URL_SendMessage -Method Post -ContentType 'application/json; charset=utf-8' -Body $json
    Write-Verbose "[c] >me $text"
    return $Temp.result
}

function SendReport {
    param (
        [ASDataExemplar]$ASData = $null,
        [string] $Target = $null,
        [bool] $IsIP = $false
    )
    if ($null -eq $ASData) {
        return $false
    }
    if ($null -eq $Target) {
        return $false;
    }
    [string] $Report = "<pre>Report generated at $([datetime]::UtcNow) UTC`n"
    $Report += "Target   : $Target`n";
    $Report += "Country  : $($ASData.CountryCode)`n";
    $Report += "Provider : $($ASData.Name)`n";
    $Report += "Network  : $($ASData.CIDR)`n";
    $Report += "AS Number: $($ASData.ASNumber)`n";
    if ($IsIP) {
        $Report += "Target defined directly via IP.`nThis is definitely IT Army fault`n";
    }
    $Report += "</pre>"
    $null = SendMessage $GroupID $Report

}
#############################################################################################################
############## GitHub Functions #############################################################################
function GetLastCommitHash {
    # https://api.github.com/repos/db1000n-coordinators/LoadTestConfig/commits
    $JsonData = Invoke-WebRequest -Uri "https://api.github.com/repos/db1000n-coordinators/LoadTestConfig/commits" | ConvertFrom-Json;
    $LastCommit = $JsonData[0].sha;
    return $LastCommit
}
#############################################################################################################
$StrIsActive = "📯 Heimdall starts to watch IT Army`r`n";
$StrLaunchingDP = "Launching domain processor...";
$StrGetTargets = "Aquiring targets...";


$TotalStopwatch = [system.diagnostics.stopwatch]::StartNew();
$null = Announce $StrIsActive;
$host.UI.RawUI.WindowTitle = "📯 Heimdall";
$Stopwatch = [system.diagnostics.stopwatch]::StartNew();
$CurrentCommit = GetLastCommitHash;
[bool] $FullCheck = $False;
$null = [System.Console]::WriteLine("Current commit is $CurrentCommit.`r`nLast processed commit is $LastHash");
if ($CurrentCommit -eq $LastHash) {
    $null = [System.Console]::Write("No new targets.`r`n");
}
else {
    $FullCheck = $true;
}
$null = Announce $StrLaunchingDP;
$DomainProcessor = [DomainProcessor]::new($PSScriptRoot);
$null = [System.Console]::beep();
$null = [System.Console]::Write(" done in $($Stopwatch.Elapsed) `r`n");
$null = $Stopwatch.Restart();

$null = Announce $StrGetTargets;
$TargetList = CreateTargetList
$null = [System.Console]::Beep();
$null = [System.Console]::Write(" done in $($Stopwatch.Elapsed) `r`n");
$WrongTargets = 0;
[System.Collections.Generic.List[string]] $DomainList = @();

foreach ($Target in $TargetList) {
    $null = [System.Console]::Write("Processing ``$Target``                                  `r");
    $ASData = $null;
    if ($null -eq $Target) {
        continue;
    }
    if ("True" -eq $Target) {
        continue;
    }
    $IsIP = IsIP $Target;
    if ($IsIP) {
        $ASData = $DomainProcessor.ASData.GetASDataByIP($Target);
        if ($ASData.ASNumber -eq 0) {
            continue;
        }
        if ($ASData.CountryCode -eq "RU") {
            continue;
        }
        elseif ($ASData.CountryCode -eq "BY") {
            continue;
        }
        else {
            $null = Announce "Found non russian target $Target!";
            $null = [System.Console]::Write("`r`n");
            $null = SendReport $ASData $Target $IsIP;
            $WrongTargets += 1;
        }
    }
    else {
        $Answers = Resolve-Dns $Target -QueryClass "IN" -NameServer $DomainProcessor.DNSServerList -ErrorAction SilentlyContinue | Select-Object Answers -ExpandProperty Answers;
        $null = $DomainList.Add($Target);
        foreach ($Answer in $Answers) {
            $IP = $Answer.Address.IPAddressToString;
            $ASData = $DomainProcessor.ASData.GetASDataByIP($IP);
            if ($ASData.ASNumber -eq 0) {
                continue;
            }
            if ($ASData.CountryCode -eq "RU") {
                continue;
            }
            elseif ($ASData.CountryCode -eq "BY") {
                continue;
            }
            else {
                Announce "Found non russian target $Target!                                             ";
                $null = [System.Console]::Write("`r`n");
                $null = SendReport $ASData $Target $IsIP;
                $WrongTargets += 1;
            }
        }
    }

}
if ((0 -eq $WrongTargets) -and ($FullCheck -eq $True)) {
    [string] $Report = "<pre>Report generated at $([datetime]::UtcNow) UTC`n"
    $Report += "All clear: only RU/BY targets.`n";
    $Report += "</pre>"
    $null = SendMessage $GroupID $Report
}
#$FinalResults | Export-Csv -Path "$PSScriptRoot\result.csv" -Encoding utf8BOM;
$TotalStopwatch.Stop();
[System.Console]::beep();
[System.Console]::WriteLine("Whole time is $($TotalStopwatch.Elapsed)...");
if ($CurrentCommit -eq $LastHash) {

}
else {
    $xmlConfig.config.lasthash = $CurrentCommit;
    $null = $xmlConfig.Save($ConfigPath);
}