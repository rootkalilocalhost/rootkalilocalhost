﻿using module ..\Classes\classes.psm1

$ErrorActionPreference = "Continue";
[Console]::OutputEncoding = [Text.UTF8Encoding]::UTF8;
$ConfigPath = Join-Path -Path $PSScriptRoot -ChildPath "tg-bot.xml";
[xml]$xmlConfig = Get-Content -Path $ConfigPath;
$token = $xmlConfig.config.system.token;
$GroupID = $xmlConfig.config.system.group_id;
# Telegram URLs
$URL_SendMessage = "https://api.telegram.org/bot$token/sendMessage";

$LastHash = $xmlConfig.config.lasthash;

<# Links:
AS Numbers - AS Names:
https://ftp.ripe.net/ripe/asnames/asn.txt

IPv4 - AS Number
https://thyme.apnic.net/current/data-raw-table

IPv6 - AS Number
https://thyme.apnic.net/current/ipv6-raw-table

Public DNS Servers:
https://public-dns.info/nameservers.txt

IT Army target list:
https://raw.githubusercontent.com/db1000n-coordinators/LoadTestConfig/main/config.v0.7.json
https://api.github.com/repos/db1000n-coordinators/LoadTestConfig/commits
#>

#############################################################################################################
################ Telegram functions #########################################################################
function SendMessage($ChatID, $text, $ReplyTo = $null) {
    if ((-not $ChatID) -or (-not $text)) {
        Write-Error "[E] Function SendMessage called without critical parameter! $ChatID $text"
        return $null
    }
    if ($null -eq $ReplyTo) {
        $ht = @{
            text       = $text
            parse_mode = "HTML"
            chat_id    = $ChatID
        }

    }
    else {
        $ht = @{
            text                = $text
            parse_mode          = "HTML"
            chat_id             = $ChatID
            reply_to_message_id = $ReplyTo
        }
    }

    $json = $ht | ConvertTo-Json
    $Temp = Invoke-RestMethod $URL_SendMessage -Method Post -ContentType 'application/json; charset=utf-8' -Body $json
    Write-Verbose "[c] >me $text"
    return $Temp.result
}

function SendReport {
    param (
        [ASDataExemplar]$ASData = $null,
        [string] $Target = $null,
        [bool] $IsIP = $false
    )
    if ($null -eq $ASData) {
        return $false
    }
    if ($null -eq $Target) {
        return $false;
    }
    [string] $Report = "<pre>Report generated at $([datetime]::UtcNow) UTC`n"
    $Report += "Target   : $Target`n";
    $Report += "Country  : $($ASData.CountryCode)`n";
    $Report += "Provider : $($ASData.Name)`n";
    $Report += "Network  : $($ASData.CIDR)`n";
    $Report += "AS Number: $($ASData.ASNumber)`n";
    if ($IsIP) {
        $Report += "Target defined directly via IP.`nThis is definitely IT Army fault`n";
    }
    $Report += "</pre>"
    $null = SendMessage $GroupID $Report

}

[string] $Report = "<pre>Report generated at $([datetime]::UtcNow) UTC`n"
$Report += "All clear: only RU/BY targets.`n";
$Report += "</pre>"
$Result = SendMessage $GroupID $Report
$Result | Out-File -FilePath $(Join-Path -Path $PSScriptRoot -ChildPath "Result.txt")