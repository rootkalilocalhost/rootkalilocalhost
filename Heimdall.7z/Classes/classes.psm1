class DomainData {
    [string] $Domain;
    [string] $Address;
    [string] $Registrar;
    [UInt32] $ASN;
    [string] $ASName;
    [string] $CountryCode;
    [string] $Country;
    [bool] $Alive;
    [string] $Status;
    [string] $PTR;
    DomainData (
        [string] $Domain,
        [string] $Address,
        [string] $Registrar,
        [UInt32] $ASN,
        [string] $ASName,
        [string] $CountryCode,
        [string] $Country,
        [bool] $Alive,
        [string] $Status,
        [string] $PTR
    ) {
        $this.Domain = $Domain;
        $this.Address = $Address;
        $this.Registrar = $Registrar;
        $this.ASN = $ASN;
        $this.ASName = $ASName;
        $this.CountryCode = $CountryCode;
        $this.Country = $Country;
        $this.Alive = $Alive;
        $this.Status = $Status;
        $this.PTR = $PTR;
    }
}
class ASDataExemplar {
    [UInt32] $ASNumber;
    [string] $Name;
    [string] $CIDR;
    [bigint] $StartAddress;
    [bigint] $EndAddress;
    [string] $CountryCode;
    ASDataExemplar (
        [UInt32] $ASNumber,
        [string] $Name,
        [string] $CIDR,
        [bigint] $StartAddress,
        [bigint] $EndAddress,
        [string] $CountryCode
    ) {
        $this.ASNumber = $ASNumber;
        $this.Name = $Name;
        $this.CIDR = $CIDR;
        $this.StartAddress = $StartAddress;
        $this.EndAddress = $EndAddress;
        $this.CountryCode = $CountryCode;
    }
}
class ASData {
    ### FIELDS
    $ASList = @{};
    [System.Collections.Generic.List[ASDataExemplar]] $ASDataList = @();
    [string] $RootDir;
    hidden $IPv4Data = @{
        Link = "https://thyme.apnic.net/.combined/data-raw-table";
        File = "v4.dat";
    }
    hidden $IPv6Data = @{
        Link = "https://thyme.apnic.net/.combined/ipv6-raw-table";
        File = "v6.dat";
    }
    hidden $ASData = @{
        Link = "https://ftp.ripe.net/ripe/asnames/asn.txt";
        File = "AS.dat"
    }
    # METHODS
    [bool] hidden DownloadData() {
        $ErrorActionPreference = 'Break';
        $Datasets = @($this.IPv4Data, $this.IPv6Data, $this.ASData);
        foreach ($Dataset in $Datasets) {
            $Datadir = Join-Path -Path "$($this.RootDir)" -ChildPath "data"
            $FilePath = Join-Path -Path "$($Datadir)" -ChildPath $($Dataset["File"]);
            [bool] $ShouldDownload = $false;
            if (-not (Test-Path $FilePath)) {
                $ShouldDownload = $true;
            }
            if (Test-Path $FilePath) {
                $LastWrite = (Get-Item $FilePath).LastWriteTime
                $Timespan = New-TimeSpan -Hours 12;
                if (((get-date) - $LastWrite) -gt $Timespan) {
                    $ShouldDownload = $true;
                }
            }
            else {
                $ShouldDownload = $true;
            }
            if ($ShouldDownload) {
                $httpClient = New-Object System.Net.Http.HttpClient;
                $null = $httpClient.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                $Response = $httpClient.GetAsync($Dataset["Link"]);
                try {
                    $Response.Wait();
                }
                catch {
                    return $false;
                }
                $FileStream = New-Object System.IO.FileStream($FilePath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write);
                $DownloadTask = $Response.Result.Content.CopyToAsync($FileStream);
                $null = $DownloadTask.Wait();
                $null = $FileStream.Close();
                $null = $httpClient.Dispose();
            }
        }
        return $true;
    }
    [void] hidden PopulateASList() {
        $null = $this.ASList.Add(0 , "Reserved / unroutable / invalid~ZZ");
        $Datadir = Join-Path -Path "$($this.RootDir)" -ChildPath "data";
        $FileName = Join-Path -Path "$($Datadir)" -ChildPath $($this.ASData["File"]);
        $Data = [IO.File]::OpenText("$Filename");
        while ($Data.Peek() -ge 0) {
            $Line = $Data.ReadLine() -replace '(^\s+ | \s+$)', '' -replace '\s+', ' ';
            [string]$Country = $Line.Substring($Line.Length - 2);
            $Line = $Line -replace ".{2}$"
            [UInt32]$ASNumber, [string]$Name = $($Line -replace '\s+', ' ').Split();
            if ($ASNumber -eq 0) {
                continue;
            }
            $Name = $Name -replace '\s', '';
            $Name = $Name -replace ',', '，';
            $Name = $Name -replace ".{1}$";
            $Country = $Country -replace '\s', '';
            if ($Name.Length -le 1) {
                $Name = "Unknown Name";
            }
            if ($Country.Length -le 1) {
                $Country = "ZZ";
            }
            if ($Name -eq "UNASSIGNED") {
                $Country = "ZZ";
            }
            if ($Name -eq "UNALLOCATED") {
                $Country = "ZZ";
            }
            $ToAdd = "$Name~$Country";
            $null = $this.ASList.Add("$ASNumber", "$ToAdd");
        }
        $null = $Data.Dispose();
    }
    [void] PopulateASData() {
        $ReservedNetworksv4 = @(
            "0.0.0.0/8",
            "10.0.0.0/8",
            "100.64.0.0/10",
            "127.0.0.0/8",
            "169.254.0.0/16"
            "172.16.0.0/12",
            "192.0.0.0/24",
            "192.0.2.0/24",
            "192.88.99.0/24",
            "192.168.0.0/16",
            "198.18.0.0/15",
            "198.51.100.0/24",
            "203.0.113.0/24",
            "224.0.0.0/4",
            "233.252.0.0/24",
            "240.0.0.0/4",
            "255.255.255.255/32"
        );
        foreach ($CIDR in $ReservedNetworksv4) {
            $ASNumber = 0;
            $Name = "Reserved IPv4 Address space";
            $CountryCode = "ZZ";
            $IPStart, $IPEnd = $this.CIDRtoRange($CIDR);
            $ASDataExemplar = [ASDataExemplar]::new($ASNumber, $Name, $CIDR, $IPStart, $IPEnd, $CountryCode);
            $null = $this.ASDataList.Add($ASDataExemplar);
        }
        <#
        ::ffff:0:0/96 	::ffff:0.0.0.0 	::ffff:255.255.255.255 	2128 − 96 = 232 = 4294967296 	Software 	IPv4-mapped addresses
        ::ffff:0:0:0/96 	::ffff:0:0.0.0.0 	::ffff:0:255.255.255.255 	232 	Software 	IPv4 translated addresses
        64:ff9b::/96 	64:ff9b::0.0.0.0 	64:ff9b::255.255.255.255 	232, with 2128 for each IPv4 	Global Internet 	IPv4/IPv6 translation[13]
        64:ff9b:1::/48 	64:ff9b:1:: 	64:ff9b:1:ffff:ffff:ffff:ffff:ffff 	242, with 280 for each IPv4 	Private internets 	IPv4/IPv6 translation[14]
        100::/64 	100:: 	100::ffff:ffff:ffff:ffff 	264 	Routing 	Discard prefix[15]
        2001:0000::/32 	2001:: 	2001::ffff:ffff:ffff:ffff:ffff:ffff 	296 	Global Internet 	Teredo tunneling[16]
        2001:20::/28 	2001:20:: 	2001:2f:ffff:ffff:ffff:ffff:ffff:ffff 	2100 	Software 	ORCHIDv2[17]
        2001:db8::/32 	2001:db8:: 	2001:db8:ffff:ffff:ffff:ffff:ffff:ffff 	296 	Documentation 	Addresses used in documentation and example source code[18]
        2002::/16 	2002:: 	2002:ffff:ffff:ffff:ffff:ffff:ffff:ffff 	2112 	Global Internet 	The 6to4 addressing scheme (deprecated)[7]
        fc00::/7 	fc00:: 	fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff 	2121 	Private internets 	Unique local address[19]
        fe80::/64 from fe80::/10 	fe80:: 	fe80::ffff:ffff:ffff:ffff 	264 	Link 	Link-local address
        ff00::/8 	ff00:: 	ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff 	2120 	Global Internet 	Multicast address
        #>
        $ReservedNetworksv6 = @(
            "64:ff9b::/96",
            "64:ff9b:1::/48",
            "100::/64",
            "2001:db8::/32",
            "2002::/16",
            "fc00::/7 ",
            "fe80::/64",
            "ff00::/8"
        );
        foreach ($CIDR in $ReservedNetworksv6) {
            $ASNumber = 0;
            $Name = "Reserved IPv6 Address space";
            $CountryCode = "ZZ";
            $IPStart, $IPEnd = $this.CIDRtoRange($CIDR);
            $ASDataExemplar = [ASDataExemplar]::new($ASNumber, $Name, $CIDR, $IPStart, $IPEnd, $CountryCode);
            $null = $this.ASDataList.Add($ASDataExemplar);
        }

        if ($this.ASDataList.Count -lt 1) {
            throw "AS Data List is empty $($this.ASDataList)";
        }
        $Datadir = Join-Path -Path "$($this.RootDir)" -ChildPath "data";
        $FileName = Join-Path -Path "$($Datadir)" -ChildPath $($this.IPv4Data["File"]);
        $Data = [IO.File]::OpenText("$FileName");
        while ($Data.Peek() -ge 0) {
            $Line = $Data.ReadLine();
            [string]$CIDR, [string]$ASNumber = $($Line -replace '\s+', ' ').Split();
            $ErrorActionPreference = 'SilentlyContinue';
            try {
                $ASNumber = [UInt32] $ASNumber;
            }
            catch {
                $ASNumber = 0;
            }
            $ErrorActionPreference = 'Stop';
            $IPStart, $IPEnd = $this.CIDRtoRange($CIDR);
            $ASInfo = $this.ASList["$ASNumber"];
            if ($null -eq $ASInfo) {
                $Name = "Unallocated AS Number";
                $CountryCode = "ZZ"
            }
            else {
                $Name, $CountryCode = $ASInfo.Split("~");
            }
            $ASDataExemplar = [ASDataExemplar]::new($ASNumber, $Name, $CIDR, $IPStart, $IPEnd, $CountryCode);
            $null = $this.ASDataList.Add($ASDataExemplar);
        }
        $null = $Data.Dispose();
        $Datadir = Join-Path -Path "$($this.RootDir)" -ChildPath "data";
        $FileName = Join-Path -Path "$($Datadir)" -ChildPath $($this.IPv6Data["File"]);
        $Data = [IO.File]::OpenText("$FileName");
        while ($Data.Peek() -ge 0) {
            $Line = $Data.ReadLine();
            [string]$CIDR, [string]$ASNumber = $($Line -replace '\s+', ' ').Split();
            $ErrorActionPreference = 'SilentlyContinue';
            try {
                $ASNumber = [UInt32] $ASNumber;
            }
            catch {
                $ASNumber = 0;
            }
            $ErrorActionPreference = 'Stop';
            $IPStart, $IPEnd = $this.CIDRtoRange($CIDR);
            $ASInfo = $this.ASList["$ASNumber"];
            if ($null -eq $ASInfo) {
                $Name = "Unallocated AS Number";
                $CountryCode = "ZZ"
            }
            else {
                $Name, $CountryCode = $ASInfo.Split("~");
            }
            $ASDataExemplar = [ASDataExemplar]::new($ASNumber, $Name, $CIDR, $IPStart, $IPEnd, $CountryCode);
            $null = $this.ASDataList.Add($ASDataExemplar);
        }
        $null = $Data.Dispose();
        $this.ASDataList.ToArray() | Export-Csv -Path $($this.RootDir + "\asdata.csv") -Force -Encoding utf8BOM

    }
    [System.Collections.Generic.List[ASDataExemplar]] GetASDataByASN (
        [UInt32] $ASN
    ) {
        $Result = [System.Collections.Generic.List[ASDataExemplar]]@();
        foreach ($AS in $this.ASDataList) {
            if ($ASN -eq $AS.ASNumber) {
                $null = $Result.Add($AS);
            }
        }
        if ($Result.Count -eq 0) {
            return $null;
        }
        else {
            return $Result;
        }
    }
    [System.Collections.Generic.List[ASDataExemplar]] GetASDataByCountryCode (
        [string] $CountryCode
    ) {
        $Result = [System.Collections.Generic.List[ASDataExemplar]]@();
        foreach ($AS in $this.ASDataList) {
            if ($CountryCode -eq $AS.CountryCode) {
                $null = $Result.Add($AS);
            }
        }
        if ($Result.Count -eq 0) {
            return $null;
        }
        else {
            return $Result;
        }
    }
    [ASDataExemplar] GetASDataByIP (
        [string] $IP
    ) {
        $IPInt = $this.IPtoBigInt($IP);
        [bool] $Done = $false
        $ASListSize = $this.ASDataList.Count;
        $I = 0;
        while (-not $Done) {
            $AS = $this.ASDataList[$I];
            if (($IPInt -ge $AS.StartAddress) -and ($IPInt -le $AS.EndAddress)) {
                return $AS;
            }
            $I = $I + 1;
            if ($I -ge $ASListSize) {
                return $this.GetASDataByASN(0);
            }
        }
        return $this.GetASDataByASN(0);
    }
    [bigint] IPtoBigInt (
        [string] $IPAddress
    ) {
        if ([string]::IsNullOrEmpty($IPAddress)) {
            return $null;
        }
        [ipaddress] $Addr = [ipaddress]::Parse($IPAddress);
        [byte[]]$AddressBytes = $Addr.GetAddressBytes();
        $AddressBytesReversed = $AddressBytes;
        [array]::Reverse($AddressBytesReversed);
        $AddressLength = $AddressBytes.Count;
        [bigint] $Result = 0;
        for ($i = 0; $i -lt $AddressLength; $i = $i + 1) {
            $NonNegativeByte = [UInt32]($AddressBytesReversed[$i]);
            [bigint] $Multiplier = [bigint]::Pow(256, ($i));
            [bigint] $ByteValue = [bigint]::Multiply($([bigint]::new($NonNegativeByte)), $Multiplier);
            $Result = $Result + $ByteValue;
        }
        return $Result;
    }
    [PSCustomObject] CIDRtoRange (
        [string] $CIDR
    ) {
        [string]$Addr, [UInt16] $Mask = $CIDR -split ("/");
        [ipaddress] $Address = [ipaddress]::Parse($Addr);

        [byte[]]$AddressBytes = $Address.GetAddressBytes();
        $AddressBytesReversed = $AddressBytes;
        [array]::Reverse($AddressBytesReversed);
        $AddressLength = $AddressBytes.Count;
        [bigint] $StartAddress = 0;
        for ($i = 0; $i -lt $AddressLength; $i = $i + 1) {
            $NonNegativeByte = [UInt32]($AddressBytesReversed[$i]);
            [bigint] $Multiplier = [bigint]::Pow(256, ($i));
            [bigint] $ByteValue = [bigint]::Multiply($([bigint]::new($NonNegativeByte)), $Multiplier);
            $StartAddress = $StartAddress + $ByteValue;
        }

        if ($Address.AddressFamily -eq "InterNetwork") {
            [bigint] $EndAddress = $StartAddress + [bigint]::Pow(2, (32 - $Mask));
        }
        else {
            [bigint] $EndAddress = $StartAddress + [bigint]::Pow(2, (128 - $Mask));
        }
        [PSCustomObject] $Result = @($StartAddress, $EndAddress);
        return $Result;
    }
    ASData (
        [string] $WorkDir
    ) {
        if ([string]::IsNullOrEmpty($WorkDir)) {
            throw "Working directory cannot be empty!"
        }
        if ([string]::IsNullOrWhiteSpace($WorkDir)) {
            throw "Working directory cannot be empty!"
        }
        $this.RootDir = $WorkDir
        $null = $this.DownloadData();
        $null = $this.PopulateASList();
        if ($null -eq $this.ASList[0]) {
            throw "AS List was NOT populated!";
        }
        $this.ASList
        $null = $this.PopulateASData();
        if ($null -eq $this.ASDataList[0]) {
            throw "AS Data was NOT populated!"
        }
    }
}

class DomainProcessor {
    [string] $RootDir;
    [ASData] $ASData;
    [System.Collections.Generic.List[string]] $DNSServerList = @();
    [string] $DigExe;
    hidden $DNSServersData = @{
        File = "nameservers.csv";
        Link = "https://public-dns.info/nameservers.csv"
    }
    [string] GetCountry([string] $Code) {
        if ($null -eq $Code) { return "Moon" };
        switch ($Code) {
            "AD" { return "Andorra" };
            "AE" { return "United Arab Emirates" };
            "AF" { return "Afghanistan" };
            "AG" { return "Antigua and Barbuda" };
            "AI" { return "Anguilla" };
            "AL" { return "Albania" };
            "AM" { return "Armenia" };
            "AO" { return "Angola" };
            "AQ" { return "Antarctica" };
            "AR" { return "Argentina" };
            "AS" { return "American Samoa" };
            "AT" { return "Austria" };
            "AU" { return "Australia" };
            "AW" { return "Aruba" };
            "AX" { return "Åland Islands" };
            "AZ" { return "Azerbaijan" };
            "BA" { return "Bosnia and Herzegovina" };
            "BB" { return "Barbados" };
            "BD" { return "Bangladesh" };
            "BE" { return "Belgium" };
            "BF" { return "Burkina Faso" };
            "BG" { return "Bulgaria" };
            "BH" { return "Bahrain" };
            "BI" { return "Burundi" };
            "BJ" { return "Benin" };
            "BL" { return "Saint Barthélemy" };
            "BM" { return "Bermuda" };
            "BN" { return "Brunei Darussalam" };
            "BO" { return "Bolivia (Plurinational State of)" };
            "BQ" { return "Bonaire, Sint Eustatius and Saba" };
            "BR" { return "Brazil" };
            "BS" { return "Bahamas" };
            "BT" { return "Bhutan" };
            "BV" { return "Bouvet Island" };
            "BW" { return "Botswana" };
            "BY" { return "Belarus" };
            "BZ" { return "Belize" };
            "CA" { return "Canada" };
            "CC" { return "Cocos (Keeling) Islands" };
            "CD" { return "Congo, Democratic Republic of the" };
            "CF" { return "Central African Republic" };
            "CG" { return "Congo" };
            "CH" { return "Switzerland" };
            "CI" { return "Côte d'Ivoire" };
            "CK" { return "Cook Islands" };
            "CL" { return "Chile" };
            "CM" { return "Cameroon" };
            "CN" { return "China" };
            "CO" { return "Colombia" };
            "CR" { return "Costa Rica" };
            "CU" { return "Cuba" };
            "CV" { return "Cabo Verde" };
            "CW" { return "Curaçao" };
            "CX" { return "Christmas Island" };
            "CY" { return "Cyprus" };
            "CZ" { return "Czechia" };
            "DE" { return "Germany" };
            "DJ" { return "Djibouti" };
            "DK" { return "Denmark" };
            "DM" { return "Dominica" };
            "DO" { return "Dominican Republic" };
            "DZ" { return "Algeria" };
            "EC" { return "Ecuador" };
            "EE" { return "Estonia" };
            "EG" { return "Egypt" };
            "EH" { return "Western Sahara" };
            "ER" { return "Eritrea" };
            "ES" { return "Spain" };
            "ET" { return "Ethiopia" };
            "EU" { return "European Union" };
            "FI" { return "Finland" };
            "FJ" { return "Fiji" };
            "FK" { return "Falkland Islands (Malvinas)" };
            "FM" { return "Micronesia (Federated States of)" };
            "FO" { return "Faroe Islands" };
            "FR" { return "France" };
            "GA" { return "Gabon" };
            "GB" { return "United Kingdom of Great Britain and Northern Ireland" };
            "GD" { return "Grenada" };
            "GE" { return "Georgia" };
            "GF" { return "French Guiana" };
            "GG" { return "Guernsey" };
            "GH" { return "Ghana" };
            "GI" { return "Gibraltar" };
            "GL" { return "Greenland" };
            "GM" { return "Gambia" };
            "GN" { return "Guinea" };
            "GP" { return "Guadeloupe" };
            "GQ" { return "Equatorial Guinea" };
            "GR" { return "Greece" };
            "GS" { return "South Georgia and the South Sandwich Islands" };
            "GT" { return "Guatemala" };
            "GU" { return "Guam" };
            "GW" { return "Guinea-Bissau" };
            "GY" { return "Guyana" };
            "HK" { return "Hong Kong" };
            "HM" { return "Heard Island and McDonald Islands" };
            "HN" { return "Honduras" };
            "HR" { return "Croatia" };
            "HT" { return "Haiti" };
            "HU" { return "Hungary" };
            "ID" { return "Indonesia" };
            "IE" { return "Ireland" };
            "IL" { return "Israel" };
            "IM" { return "Isle of Man" };
            "IN" { return "India" };
            "IO" { return "British Indian Ocean Territory" };
            "IQ" { return "Iraq" };
            "IR" { return "Iran (Islamic Republic of)" };
            "IS" { return "Iceland" };
            "IT" { return "Italy" };
            "JE" { return "Jersey" };
            "JM" { return "Jamaica" };
            "JO" { return "Jordan" };
            "JP" { return "Japan" };
            "KE" { return "Kenya" };
            "KG" { return "Kyrgyzstan" };
            "KH" { return "Cambodia" };
            "KI" { return "Kiribati" };
            "KM" { return "Comoros" };
            "KN" { return "Saint Kitts and Nevis" };
            "KP" { return "Korea (Democratic People's Republic of)" };
            "KR" { return "Korea, Republic of" };
            "KW" { return "Kuwait" };
            "KY" { return "Cayman Islands" };
            "KZ" { return "Kazakhstan" };
            "LA" { return "Lao People's Democratic Republic" };
            "LB" { return "Lebanon" };
            "LC" { return "Saint Lucia" };
            "LI" { return "Liechtenstein" };
            "LK" { return "Sri Lanka" };
            "LR" { return "Liberia" };
            "LS" { return "Lesotho" };
            "LT" { return "Lithuania" };
            "LU" { return "Luxembourg" };
            "LV" { return "Latvia" };
            "LY" { return "Libya" };
            "MA" { return "Morocco" };
            "MC" { return "Monaco" };
            "MD" { return "Moldova, Republic of" };
            "ME" { return "Montenegro" };
            "MF" { return "Saint Martin (French part)" };
            "MG" { return "Madagascar" };
            "MH" { return "Marshall Islands" };
            "MK" { return "North Macedonia" };
            "ML" { return "Mali" };
            "MM" { return "Myanmar" };
            "MN" { return "Mongolia" };
            "MO" { return "Macao" };
            "MP" { return "Northern Mariana Islands" };
            "MQ" { return "Martinique" };
            "MR" { return "Mauritania" };
            "MS" { return "Montserrat" };
            "MT" { return "Malta" };
            "MU" { return "Mauritius" };
            "MV" { return "Maldives" };
            "MW" { return "Malawi" };
            "MX" { return "Mexico" };
            "MY" { return "Malaysia" };
            "MZ" { return "Mozambique" };
            "NA" { return "Namibia" };
            "NC" { return "New Caledonia" };
            "NE" { return "Niger" };
            "NF" { return "Norfolk Island" };
            "NG" { return "Nigeria" };
            "NI" { return "Nicaragua" };
            "NL" { return "Netherlands" };
            "NO" { return "Norway" };
            "NP" { return "Nepal" };
            "NR" { return "Nauru" };
            "NU" { return "Niue" };
            "NZ" { return "New Zealand" };
            "OM" { return "Oman" };
            "PA" { return "Panama" };
            "PE" { return "Peru" };
            "PF" { return "French Polynesia" };
            "PG" { return "Papua New Guinea" };
            "PH" { return "Philippines" };
            "PK" { return "Pakistan" };
            "PL" { return "Poland" };
            "PM" { return "Saint Pierre and Miquelon" };
            "PN" { return "Pitcairn" };
            "PR" { return "Puerto Rico" };
            "PS" { return "Palestine, State of" };
            "PT" { return "Portugal" };
            "PW" { return "Palau" };
            "PY" { return "Paraguay" };
            "QA" { return "Qatar" };
            "RE" { return "Réunion" };
            "RO" { return "Romania" };
            "RS" { return "Serbia" };
            "RU" { return "Russian Federation" };
            "RW" { return "Rwanda" };
            "SA" { return "Saudi Arabia" };
            "SB" { return "Solomon Islands" };
            "SC" { return "Seychelles" };
            "SD" { return "Sudan" };
            "SE" { return "Sweden" };
            "SG" { return "Singapore" };
            "SH" { return "Saint Helena, Ascension and Tristan da Cunha" };
            "SI" { return "Slovenia" };
            "SJ" { return "Svalbard and Jan Mayen" };
            "SK" { return "Slovakia" };
            "SL" { return "Sierra Leone" };
            "SM" { return "San Marino" };
            "SN" { return "Senegal" };
            "SO" { return "Somalia" };
            "SR" { return "Suriname" };
            "SS" { return "South Sudan" };
            "ST" { return "Sao Tome and Principe" };
            "SV" { return "El Salvador" };
            "SX" { return "Sint Maarten (Dutch part)" };
            "SY" { return "Syrian Arab Republic" };
            "SZ" { return "Eswatini" };
            "TC" { return "Turks and Caicos Islands" };
            "TD" { return "Chad" };
            "TF" { return "French Southern Territories" };
            "TG" { return "Togo" };
            "TH" { return "Thailand" };
            "TJ" { return "Tajikistan" };
            "TK" { return "Tokelau" };
            "TL" { return "Timor-Leste" };
            "TM" { return "Turkmenistan" };
            "TN" { return "Tunisia" };
            "TO" { return "Tonga" };
            "TR" { return "Türkiye" };
            "TT" { return "Trinidad and Tobago" };
            "TV" { return "Tuvalu" };
            "TW" { return "Taiwan" };
            "TZ" { return "Tanzania, United Republic of" };
            "UA" { return "Ukraine" };
            "UG" { return "Uganda" };
            "UM" { return "United States Minor Outlying Islands" };
            "US" { return "United States of America" };
            "UY" { return "Uruguay" };
            "UZ" { return "Uzbekistan" };
            "VA" { return "Holy See" };
            "VC" { return "Saint Vincent and the Grenadines" };
            "VE" { return "Venezuela (Bolivarian Republic of)" };
            "VG" { return "Virgin Islands (British)" };
            "VI" { return "Virgin Islands (U.S.)" };
            "VN" { return "Viet Nam" };
            "VU" { return "Vanuatu" };
            "WF" { return "Wallis and Futuna" };
            "WS" { return "Samoa" };
            "YE" { return "Yemen" };
            "YT" { return "Mayotte" };
            "ZA" { return "South Africa" };
            "ZM" { return "Zambia" };
            "ZW" { return "Zimbabwe" };
            Default { return "Unknown country" };
        }
        return "Mars"
    }
    [void] PopulateDNSServerList () {
        $DataLink = $this.DNSServersData["Link"];
        $Datadir = Join-Path -Path "$($this.RootDir)" -ChildPath "data";
        $DataPath = Join-Path -Path "$($Datadir)" -ChildPath $($this.DNSServersData["File"]);
        [bool] $ShouldDownload = $false;
        if (-not (Test-Path $DataPath)) {
            $ShouldDownload = $true;
        }
        if (Test-Path $DataPath) {
            $LastWrite = (Get-Item $DataPath).LastWriteTime
            $Timespan = New-TimeSpan -Hours 12;
            if (((get-date) - $LastWrite) -gt $Timespan) {
                $ShouldDownload = $true;
            }
        }
        else {
            $ShouldDownload = $true;
        }
        if ($ShouldDownload) {
            $Successful = $false;
            while (-not $Successful) {
                $httpClient = New-Object System.Net.Http.HttpClient;
                $null = $httpClient.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                $Response = $httpClient.GetAsync($Datalink);
                try {
                    $Response.Wait();
                    $Successful = $true;
                }
                catch {
                    $Successful = $false;
                    $httpClient = $null;
                    continue;
                }
                $FileStream = New-Object System.IO.FileStream($DataPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write);
                $DownloadTask = $Response.Result.Content.CopyToAsync($FileStream);
                $null = $DownloadTask.Wait();
                $null = $FileStream.Close();
                $null = $httpClient.Dispose();
            }
        }

        $Data = Import-Csv $DataPath
        foreach ($Server in $Data) {
            if ($Server.country_code -eq "RU") {
                continue;
            }
            if ($Server.country_code -eq "BY") {
                continue;
            }
            if ($Server.country_code -eq "UA") {
                continue;
            }
            if ($Server.country_code -eq "TM") {
                continue;
            }
            if ($Server.country_code -eq "KZ") {
                continue;
            }
            if ($Server.country_code -eq "CN") {
                continue;
            }
            if ($Server.reliability -eq "1.00") {
                $null;
            }
            else {
                continue;
            }
            $Timespan = New-TimeSpan -Days 1;
            $Now = Get-Date;
            $ServerChecked = Get-Date $Server.checked_at;
            if (($Now - $ServerChecked) -gt $Timespan) {
                continue;
            }
            $IP = $Server.ip_address;
            $this.DNSServerList.Add($IP);
        }
        $Data = $null;
        $this.DNSServerList.ToArray() | Out-File -Path $(Join-Path -Path $this.RootDir -ChildPath "dnsservers.dat");
    }
    [void] EnsureDiG () {
        if (-not (Get-Module -ListAvailable -Name "DnsClient-PS")) {
            $null = Install-Module -Name DnsClient-PS -Scope CurrentUser -Force
        }
    }
    [System.Collections.Generic.List[DomainData]] ProcessDomain (
        [string] $Argument
    ) {
        [string]$Domain, [string] $Registrar = $Argument -split ("~");
        if ($null -eq $Domain) {
            return $false;
        }
        if ($null -eq $Registrar) {
            return $false;
        }
        $DomainResolved = $false;
        $null = Set-DnsClientSetting -Timeout 1 -Retries 1 -UseTcpFallback;
        while (-not $DomainResolved) {
            $Results = @();
            $Response = $null;
            while ($null -eq $Response) {
                $Servers = [System.Collections.Generic.List[string]]::new();
                for ($i = 0; $i -lt 4; $i = $i + 1) {
                    $Server = $this.DNSServerList[(Get-Random ($this.DNSServerList.Count))];
                    $null = $Servers.Add($Server);
                }
                $Servers.Add("8.8.8.8");
                $Servers.Add("1.1.1.1");
                $NameServers = $Servers.ToArray();
                try {
                    $Response = Resolve-Dns $Domain `
                        -NameServer $NameServers `
                        -QueryType A `
                        -ContinueOnDnsError `
                        -ContinueOnEmptyResponse `
                        -ErrorAction SilentlyContinue `
                        -Timeout 1 `
                        -Retries 1;
                }
                catch {
                    $Response = $null;
                }
            }
            $Results += $Response;
            $Servers = $null;
            $NameServers = $null;
            $Response = $null;
            while ($null -eq $Response) {
                $Servers = [System.Collections.Generic.List[string]]::new();
                for ($i = 0; $i -lt 4; $i = $i + 1) {
                    $Server = $this.DNSServerList[(Get-Random ($this.DNSServerList.Count))];
                    $null = $Servers.Add($Server);
                }
                $Servers.Add("8.8.8.8");
                $Servers.Add("1.1.1.1");
                $NameServers = $Servers.ToArray();
                try {
                    $Response = Resolve-Dns $Domain `
                        -NameServer $NameServers `
                        -QueryType AAAA `
                        -ContinueOnDnsError `
                        -ContinueOnEmptyResponse `
                        -ErrorAction SilentlyContinue `
                        -Timeout 1 `
                        -Retries 1;
                }
                catch {
                    $Response = $null;
                }
            }
            $Servers = $null;
            $Results += $Response;
            [System.Collections.Generic.List[DomainData]] $ToReturn = @();
            foreach ($Result in $Results) {
                $DomainStatus = $Result.Header.ResponseCode;
                $DeadDomain = [DomainData]::new($Domain, "NONE", $Registrar, 0, "NONE", "ZZ", "NONE", $false, $DomainStatus, "NONE");
                [System.Console]::WriteLine("$Domain`: $DomainStatus");
                switch ($DomainStatus) {
                    "NoError" {
                        foreach ($Answer in $Result.Answers) {
                            [System.Console]::WriteLine("$Answer");
                            $IP = $Answer.Address.IPAddressToString;
                            $PTR = Resolve-Dns $IP -QueryType PTR -NameServer $NameServers;
                            $PtrData = "";
                            if ($PTR.HasError -eq $true ) {
                                $PtrData = "NONE";
                            }
                            else {
                                foreach ($PtrRecord in $PTR.Answers) {
                                    $Value = ($PtrRecord | Select-Object -ExpandProperty PtrDomainName).Value;
                                    if ($PtrData -eq "") {
                                        $PtrData = $Value;
                                    }
                                    else {
                                        $PtrData = "$PtrData`;$Value";
                                    }
                                }
                            }
                            $ASInfo = $this.ASData.GetASDataByIP($IP);

                            $DomainData = [DomainData]::new($Domain,
                                $IP,
                                $Registrar,
                                $ASInfo.ASNumber,
                                $ASInfo.Name,
                                $ASInfo.CountryCode,
                                ($this.GetCountry($ASInfo.CountryCode)),
                                $true,
                                $DomainStatus,
                                $PtrData);
                            $null = $ToReturn.Add($DomainData);
                            $DomainResolved = $true;
                        }
                        break;
                    };
                    "NotExistentDomain" {
                        [System.Collections.Generic.List[DomainData]] $ToReturn = @();
                        $null = $ToReturn.Add($DeadDomain);
                        $DomainResolved = $true;
                        return $ToReturn;
                        break;
                    };
                    "ServerFailure" {
                        [System.Collections.Generic.List[DomainData]] $ToReturn = @();
                        $null = $ToReturn.Add($DeadDomain);
                        $DomainResolved = $true;
                        return $ToReturn;
                        break;
                    };
                    "ExistingDomain" {
                        [System.Console]::WriteLine("$Domain`: exists while DNS Server reports it must not!");
                        break;
                    };
                    "ExistingResourceRecordSet " {
                        [System.Console]::WriteLine("$Domain`: Resource record set exists when it should not.");
                        break;
                    };
                    "FormatError" {
                        [System.Console]::WriteLine("$Domain`: Format error. The name server was unable to interpret the query.");
                        break;
                    };
                    "MissingResourceRecordSet" {
                        [System.Console]::WriteLine("$Domain`: Resource record set that should exist but does not.");
                        break;
                    };
                    "NotAuthorized" {
                        [System.Console]::WriteLine("$Domain`: Server Not Authoritative for zone / Not Authorized.");
                        break;
                    };
                    "NotImplemented" {
                        [System.Console]::WriteLine("$Domain`: Not Implemented. The name server does not support the requested kind of query.");
                        break;
                    };
                    "NotZone" {
                        [System.Console]::WriteLine("$Domain`: Name not contained in zone.");
                        break;
                    };
                    "Refused" {
                        [System.Console]::WriteLine("$Domain`: Refused. The name server refuses to perform the specified operation for policy reasons.`n`
                            For example, a name server may not wish to provide the information to the particular requester,`n`
                            or a name server may not wish to perform a particular operation (e.g., zone transfer) for particular data.");
                        continue;
                    };
                    Default {
                        [System.Console]::WriteLine("$DomainStatus of $Domain is not recognized!!!");
                        #"$DomainStatus of $Domain is not recognized!!!"
                    }
                }
            }
            if ($DomainResolved) {
                return $ToReturn;
            }
        }

        return $false;
    }
    DomainProcessor ([string] $WorkDir) {
        $this.RootDir = $WorkDir;
        $null = $this.EnsureDiG();
        $null = $this.PopulateDNSServerList();
        $this.ASData = [ASData]::new($WorkDir);
    }
}